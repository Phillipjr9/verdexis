import { Router } from 'express'
import bcrypt from 'bcryptjs'
import crypto from 'node:crypto'
import { z } from 'zod'
import rateLimit from 'express-rate-limit'
import { prisma } from '../db.js'
import { signToken, requireAuth, type AuthedRequest } from '../auth.js'
import { env } from '../env.js'
import { generateInvestmentId } from '../investmentId.js'
import { generateReferralCode, linkReferrer } from '../referrals.js'
import { isDbUnavailableError } from '../dbError.js'

const router = Router()

const ADMIN_EMAILS = env.ADMIN_EMAILS.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)

// Auth limiter. Keyed by IP **and** the submitted email/username so users
// sharing a VPN / NAT exit-IP don't lock each other out — a single bad
// actor brute-forcing one account no longer blocks everyone else behind
// the same VPN. Successful logins don't count toward the limit either,
// so legitimate users can sign in repeatedly without burning quota.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  keyGenerator: (req) => {
    const body = (req.body ?? {}) as { identifier?: string; email?: string }
    const id = String(body.identifier || body.email || '').trim().toLowerCase()
    return `${req.ip || 'anon'}|${id}`
  },
})

const signupSchema = z.object({
  email: z.string().email().toLowerCase().trim(),
  password: z.string().min(8).max(200),
  name: z.string().min(1).max(80).trim(),
  // Phone is compulsory at signup so admins can reach the user (e.g. for
  // KYC + the WhatsApp bonus-withdrawal verification step). Accepts E.164
  // or local format with at least 7 digits.
  phone: z.string().trim().min(7).max(32).regex(/^[+0-9 ()\-.]+$/, 'Invalid phone number'),
})

const loginSchema = z.object({
  // Accepts either an email or a username (3+ chars).
  identifier: z.string().min(3).max(200).trim().toLowerCase().optional(),
  email: z.string().min(3).max(200).trim().toLowerCase().optional(),
  password: z.string().min(1).max(200),
}).refine((d) => !!(d.identifier || d.email), { message: 'identifier or email required' })

const forgotSchema = z.object({
  email: z.string().email().toLowerCase().trim(),
})

const resetSchema = z.object({
  token: z.string().min(10).max(200),
  password: z.string().min(8).max(200),
})

function publicUser(u: { id: string; email: string; username?: string | null; name: string; avatar: string | null; prefs: string | null; twoFactor: boolean; role?: string; suspended?: boolean; investmentId?: string | null; kycStatus?: string; kycNotes?: string | null; kycReviewedAt?: Date | null; kycReviewedBy?: string | null; emailVerified?: boolean; emailVerifiedAt?: Date | null }) {
  let prefs: Record<string, unknown> = {}
  try {
    if (u.prefs) prefs = JSON.parse(u.prefs)
  } catch {
    prefs = {}
  }
  return {
    id: u.id,
    email: u.email,
    username: u.username ?? null,
    name: u.name,
    avatar: u.avatar,
    twoFactor: u.twoFactor,
    role: (u.role === 'admin' ? 'admin' : 'user') as 'user' | 'admin',
    suspended: !!u.suspended,
    investmentId: u.investmentId ?? null,
    kycStatus: (u.kycStatus === 'approved' || u.kycStatus === 'pending' || u.kycStatus === 'rejected') ? u.kycStatus : 'none',
    emailVerified: !!u.emailVerified,
    emailVerifiedAt: u.emailVerifiedAt ?? null,
    prefs,
  }
}

type LoginGeo = {
  country?: string
  countryCode?: string
  region?: string
  city?: string
  latitude?: number
  longitude?: number
  timezone?: string
  isp?: string
}

function getClientIp(req: { headers: Record<string, unknown>; ip?: string }): string {
  const fwd = typeof req.headers['x-forwarded-for'] === 'string'
    ? req.headers['x-forwarded-for']
    : Array.isArray(req.headers['x-forwarded-for'])
      ? req.headers['x-forwarded-for'][0]
      : ''
  const ip = (fwd?.split(',')[0]?.trim() || req.ip || '').trim()
  return ip.replace(/^::ffff:/, '')
}

function isPrivateOrLocalIp(ip: string): boolean {
  if (!ip) return true
  if (ip === '::1' || ip === '127.0.0.1' || ip === 'localhost') return true
  if (ip.startsWith('10.') || ip.startsWith('192.168.') || ip.startsWith('169.254.')) return true
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(ip)) return true
  if (ip.startsWith('fc') || ip.startsWith('fd')) return true
  return false
}

async function fetchGeoForIp(ip: string): Promise<LoginGeo | null> {
  if (!ip || isPrivateOrLocalIp(ip)) return null
  try {
    const ac = new AbortController()
    const t = setTimeout(() => ac.abort(), 1500)
    const response = await fetch(`https://ipwho.is/${encodeURIComponent(ip)}`, { signal: ac.signal })
    clearTimeout(t)
    if (!response.ok) return null
    const data = await response.json() as {
      success?: boolean
      country?: string
      country_code?: string
      region?: string
      city?: string
      latitude?: number
      longitude?: number
      timezone?: { id?: string } | string
      connection?: { isp?: string }
    }
    if (data.success === false) return null
    const timezone = typeof data.timezone === 'string' ? data.timezone : data.timezone?.id
    return {
      country: data.country,
      countryCode: data.country_code,
      region: data.region,
      city: data.city,
      latitude: data.latitude,
      longitude: data.longitude,
      timezone,
      isp: data.connection?.isp,
    }
  } catch {
    return null
  }
}

async function recordLoginMetadata(userId: string, ip: string, userAgent?: string): Promise<void> {
  try {
    const current = await prisma.user.findUnique({ where: { id: userId }, select: { prefs: true } })
    let prefs: Record<string, unknown> = {}
    try { if (current?.prefs) prefs = JSON.parse(current.prefs) } catch { prefs = {} }

    const geo = await fetchGeoForIp(ip)
    const security = (typeof prefs.security === 'object' && prefs.security) ? prefs.security as Record<string, unknown> : {}
    const history = Array.isArray(security.loginHistory) ? security.loginHistory as Array<Record<string, unknown>> : []
    const entry: Record<string, unknown> = {
      at: new Date().toISOString(),
      ip,
      userAgent: (userAgent || '').slice(0, 300),
    }
    if (geo) entry.geo = geo

    const nextSecurity = {
      ...security,
      lastLogin: entry,
      loginHistory: [entry, ...history].slice(0, 10),
    }

    await prisma.user.update({
      where: { id: userId },
      data: { prefs: JSON.stringify({ ...prefs, security: nextSecurity }) },
    })
  } catch {
    // best-effort only
  }
}

// Admins are seeded with a treasury balance they can disburse to users via
// the Admin → Transfer flow. Currently 1 trillion USD.
const ADMIN_TREASURY_USD = 1_000_000_000_000
const SIGNUP_BONUS_KEY = 'signup_bonus'

type SignupBonusConfig = {
  enabled: boolean
  amountUsd: number
  note?: string
}

async function getSignupBonusConfig(): Promise<SignupBonusConfig | null> {
  const row = await prisma.appSetting.findUnique({ where: { key: SIGNUP_BONUS_KEY } })
  if (!row?.value) return null
  try {
    const parsed = JSON.parse(row.value) as Partial<SignupBonusConfig>
    const amountUsd = Number(parsed.amountUsd)
    return {
      enabled: parsed.enabled === true,
      amountUsd: Number.isFinite(amountUsd) ? amountUsd : 0,
      note: typeof parsed.note === 'string' ? parsed.note.slice(0, 300) : undefined,
    }
  } catch {
    return null
  }
}

async function awardSignupBonus(userId: string): Promise<void> {
  const config = await getSignupBonusConfig()
  if (!config?.enabled || config.amountUsd <= 0) return

  await prisma.$transaction(async (tx) => {
    const existing = await tx.walletBalance.findUnique({ where: { userId_currency: { userId, currency: 'USD' } } })
    const currentBalance = existing?.balance ?? 0
    const currentAvailable = existing?.available ?? 0

    await tx.walletBalance.upsert({
      where: { userId_currency: { userId, currency: 'USD' } },
      create: {
        userId,
        currency: 'USD',
        symbol: '$',
        balance: config.amountUsd,
        available: config.amountUsd,
      },
      update: {
        balance: currentBalance + config.amountUsd,
        available: currentAvailable + config.amountUsd,
        symbol: '$',
      },
    })

    await tx.transaction.create({
      data: {
        userId,
        kind: 'deposit',
        currency: 'USD',
        amount: config.amountUsd,
        status: 'completed',
        subType: 'signup_bonus',
        reference: config.note?.trim() || 'New account signup bonus',
      },
    })

    // Lock bonus withdrawals until the user contacts support on WhatsApp.
    // Admins clear this flag via PATCH /api/admin/users/:id (prefs).
    const u = await tx.user.findUnique({ where: { id: userId }, select: { prefs: true } })
    let prefs: Record<string, unknown> = {}
    try { if (u?.prefs) prefs = JSON.parse(u.prefs) } catch { prefs = {} }
    prefs.bonusLocked = true
    prefs.bonusLockedAmountUsd = config.amountUsd
    prefs.bonusLockedAt = new Date().toISOString()
    await tx.user.update({ where: { id: userId }, data: { prefs: JSON.stringify(prefs) } })

    await tx.notification.create({
      data: {
        userId,
        kind: 'system',
        title: `Signup bonus received: $${config.amountUsd}`,
        body: (config.note?.trim() || 'Welcome to Verdexis — your signup bonus has been credited.') + ' To withdraw your bonus, please message support on WhatsApp (https://wa.me/17196798790) or Telegram (https://t.me/+17196798790) first.',
      },
    })
  })
}

async function ensureAdminTreasury(userId: string): Promise<void> {
  const existing = await prisma.walletBalance.findFirst({ where: { userId, currency: 'USD' } })
  if (!existing) {
    await prisma.walletBalance.create({
      data: { userId, currency: 'USD', symbol: '$', balance: ADMIN_TREASURY_USD, available: ADMIN_TREASURY_USD },
    })
  }
}

export async function autoPromoteIfAdminEmail(userId: string, email: string, currentRole: string): Promise<string> {
  if (currentRole === 'admin') {
    await ensureAdminTreasury(userId)
    return 'admin'
  }
  if (!ADMIN_EMAILS.includes(email.toLowerCase())) return currentRole
  await prisma.user.update({ where: { id: userId }, data: { role: 'admin' } })
  await ensureAdminTreasury(userId)
  return 'admin'
}

router.post('/signup', authLimiter, async (req, res) => {
  const parsed = signupSchema.safeParse(req.body)
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid input', details: parsed.error.flatten() })
    return
  }
  const { email, password, name } = parsed.data
  const existing = await prisma.user.findUnique({ where: { email } })
  if (existing) {
    res.status(409).json({ error: 'Email already registered' })
    return
  }
  const passwordHash = await bcrypt.hash(password, 12)
  const investmentId = await generateInvestmentId()
    const referralCode = await generateReferralCode()
    const referrerCode = (req.query.ref as string) || ''  // ref query param for signup with referral
  let user
  try {
    user = await prisma.user.create({
      data: {
        email,
        name,
        passwordHash,
        investmentId,
          referralCode,
        // First user signed up with an admin-listed email starts as admin.
        role: ADMIN_EMAILS.includes(email) ? 'admin' : 'user',
        // Persist the phone number in prefs so admins can see / contact the
        // user. Stored alongside any future preference data.
        prefs: JSON.stringify({ phone: parsed.data.phone }),
        // Seed a USD wallet so the user can deposit immediately.
        walletBalances: {
          create: [{ currency: 'USD', symbol: '$', balance: 0, available: 0 }],
        },
      },
    })
  } catch (e) {
    // Race: another request created this email between findUnique and create.
    // Surface 409 instead of bubbling a Prisma error to the client.
    const msg = e instanceof Error ? e.message : String(e)
    if (/Unique constraint failed/i.test(msg) || /P2002/.test(msg)) {
      res.status(409).json({ error: 'Email already registered' })
      return
    }
    throw e
  }
  if (user.role === 'admin') await ensureAdminTreasury(user.id)
  await awardSignupBonus(user.id)
    // Link to referrer if code provided
    if (referrerCode) {
      try {
        await linkReferrer(user.id, email, referrerCode)
      } catch {
        // best-effort only; don't fail signup if referral linking fails
      }
    }
  const token = signToken({ sub: user.id, email: user.email, v: user.tokenVersion })
  res.status(201).json({ token, user: publicUser(user) })
})

router.post('/login', authLimiter, async (req, res) => {
  try {
    const parsed = loginSchema.safeParse(req.body)
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid input' })
      return
    }
    const { password } = parsed.data
    const id = (parsed.data.identifier || parsed.data.email || '').trim().toLowerCase()
    // If it parses as an email, look up by email; otherwise treat as username.
    const isEmail = /.+@.+\..+/.test(id)
    const user = isEmail
      ? await prisma.user.findUnique({ where: { email: id } })
      : await prisma.user.findUnique({ where: { username: id } })
    if (!user) {
      res.status(401).json({ error: 'Invalid credentials' })
      return
    }
    const ok = await bcrypt.compare(password, user.passwordHash)
    if (!ok) {
      res.status(401).json({ error: 'Invalid credentials' })
      return
    }
    if (user.suspended) {
      res.status(403).json({ error: 'Account suspended' })
      return
    }
    let role = user.role
    try {
      role = await autoPromoteIfAdminEmail(user.id, user.email, user.role)
    } catch (promoteErr) {
      // Don't block login if promotion fails (e.g. treasury seed write race);
      // log it so we can see it in Render logs.
      console.error('[verdexis-api] autoPromote failed for', user.email, promoteErr)
    }
    const clientIp = getClientIp(req)
    void recordLoginMetadata(user.id, clientIp, String(req.headers['user-agent'] || ''))
    const token = signToken({ sub: user.id, email: user.email, v: user.tokenVersion })
    res.json({ token, user: publicUser({ ...user, role }) })
  } catch (err) {
    console.error('[verdexis-api] /login crashed:', err)
    if (isDbUnavailableError(err)) {
      res.status(503).json({
        error: 'Database unavailable',
        detail: err instanceof Error ? err.message : String(err),
      })
      return
    }
    res.status(500).json({
      error: 'Login failed',
      detail: err instanceof Error ? err.message : String(err),
    })
  }
})

router.post('/forgot', authLimiter, async (req, res) => {
  const parsed = forgotSchema.safeParse(req.body)
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid input' })
    return
  }
  const { email } = parsed.data
  const user = await prisma.user.findUnique({ where: { email } })
  // Always return ok to avoid user enumeration.
  if (user) {
    const rawToken = crypto.randomBytes(32).toString('hex')
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex')
    await prisma.passwordReset.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000), // 1 hour
      },
    })
    const resetUrl = `${process.env.APP_BASE_URL || 'http://localhost:5173'}/reset?token=${rawToken}`
    // Real email integration would go here. For dev: log it.
    console.log(`[verdexis] password reset for ${email}: ${resetUrl}`)
  }
  res.json({ ok: true, message: 'If that email exists, a reset link has been sent.' })
})

router.post('/reset', authLimiter, async (req, res) => {
  const parsed = resetSchema.safeParse(req.body)
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid input' })
    return
  }
  const tokenHash = crypto.createHash('sha256').update(parsed.data.token).digest('hex')
  const record = await prisma.passwordReset.findUnique({ where: { tokenHash } })
  if (!record || record.used || record.expiresAt < new Date()) {
    res.status(400).json({ error: 'Invalid or expired token' })
    return
  }
  const passwordHash = await bcrypt.hash(parsed.data.password, 12)
  await prisma.$transaction([
    prisma.user.update({ where: { id: record.userId }, data: { passwordHash } }),
    prisma.passwordReset.update({ where: { id: record.id }, data: { used: true } }),
  ])
  res.json({ ok: true })
})

router.get('/me', requireAuth, async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId! } })
  if (!user) {
    res.status(404).json({ error: 'Not found' })
    return
  }
  // Re-check admin promotion on every /me — covers the case where ADMIN_EMAILS
  // was set after the user already signed up/logged in (so role would otherwise
  // be stuck at 'user' until next login).
  const role = await autoPromoteIfAdminEmail(user.id, user.email, user.role)
  res.json({ user: publicUser({ ...user, role }) })
})

// One-time bootstrap: promote any user matching ADMIN_EMAILS to admin and
// seed their treasury. Safe to run repeatedly. Called from server boot.
// Also creates the admin user if missing (with seed password from
// ADMIN_SEED_PASSWORD env, falling back to "ChangeMe!2026"). Logs the
// password so the operator can find it in Render logs on first boot.
export async function promoteAllAdminEmails(): Promise<void> {
  if (!ADMIN_EMAILS.length) return
  const seedPassword = process.env.ADMIN_SEED_PASSWORD || 'ChangeMe!2026'
  for (const email of ADMIN_EMAILS) {
    try {
      let u = await prisma.user.findUnique({ where: { email } })
      if (!u) {
        // Create the admin user fresh.
        const passwordHash = await bcrypt.hash(seedPassword, 12)
        const investmentId = await generateInvestmentId()
        u = await prisma.user.create({
          data: {
            email,
            name: 'Admin',
            passwordHash,
            investmentId,
            role: 'admin',
            walletBalances: {
              create: [{ currency: 'USD', symbol: '$', balance: 0, available: 0 }],
            },
          },
        })
        console.log(`[verdexis-api] created admin user ${email} — set ADMIN_SEED_PASSWORD env var to control the initial password (and rotate it after first login)`)
      } else if (!u.passwordHash || u.passwordHash.length < 20) {
        // Repair: passwordHash is missing/corrupt — reset to seed.
        const passwordHash = await bcrypt.hash(seedPassword, 12)
        await prisma.user.update({ where: { id: u.id }, data: { passwordHash, tokenVersion: { increment: 1 } } })
        console.log(`[verdexis-api] repaired corrupt passwordHash for ${email}; reset to ADMIN_SEED_PASSWORD env (or default). Rotate immediately.`)
      }
      await autoPromoteIfAdminEmail(u.id, u.email, u.role)
      // eslint-disable-next-line no-console
      console.log(`[verdexis-api] ensured admin role for ${email}`)
    } catch (e) {
      console.error(`[verdexis-api] failed to promote ${email}:`, (e as Error).message)
    }
  }
}

router.post('/logout', (_req, res) => {
  // Token storage is client-side (Bearer); just clear the legacy cookie if
  // any client still has it lying around.
  res.clearCookie('verdexis_token')
  res.json({ ok: true })
})

// Authenticated password change (requires current password).
const changePasswordSchema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: z.string().min(8).max(200),
})
router.post('/change-password', requireAuth, authLimiter, async (req: AuthedRequest, res) => {
  const parsed = changePasswordSchema.safeParse(req.body)
  if (!parsed.success) { res.status(400).json({ error: 'Invalid input' }); return }
  const user = await prisma.user.findUnique({ where: { id: req.userId! } })
  if (!user) { res.status(404).json({ error: 'Not found' }); return }
  const ok = await bcrypt.compare(parsed.data.currentPassword, user.passwordHash)
  if (!ok) { res.status(401).json({ error: 'Current password is incorrect' }); return }
  const passwordHash = await bcrypt.hash(parsed.data.newPassword, 12)
  // Bump tokenVersion so all other sessions are invalidated.
  const updated = await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash, tokenVersion: { increment: 1 } },
  })
  // Issue a fresh token for the current session so the user stays signed in here.
  const token = signToken({ sub: updated.id, email: updated.email, v: updated.tokenVersion })
  res.json({ ok: true, token })
})

// Sign out of every other device by bumping tokenVersion.
router.post('/logout-all', requireAuth, async (req: AuthedRequest, res) => {
  const updated = await prisma.user.update({
    where: { id: req.userId! },
    data: { tokenVersion: { increment: 1 } },
  })
  const token = signToken({ sub: updated.id, email: updated.email, v: updated.tokenVersion })
  res.json({ ok: true, token })
})

// Full data export for the authenticated user (GDPR-style).
router.get('/export', requireAuth, async (req: AuthedRequest, res) => {
  const id = req.userId!
  const [user, holdings, walletBalances, transactions, trades, watchlist, alerts, notifications] = await Promise.all([
    prisma.user.findUnique({ where: { id } }),
    prisma.holding.findMany({ where: { userId: id } }),
    prisma.walletBalance.findMany({ where: { userId: id } }),
    prisma.transaction.findMany({ where: { userId: id } }),
    prisma.trade.findMany({ where: { userId: id } }),
    prisma.watchlist.findMany({ where: { userId: id } }),
    prisma.priceAlert.findMany({ where: { userId: id } }),
    prisma.notification.findMany({ where: { userId: id } }),
  ])
  if (!user) { res.status(404).json({ error: 'Not found' }); return }
  res.setHeader('Content-Type', 'application/json')
  res.setHeader('Content-Disposition', `attachment; filename="verdexis-export-${id}.json"`)
  res.json({
    exportedAt: new Date().toISOString(),
    user: publicUser(user),
    holdings, walletBalances, transactions, trades, watchlist, alerts, notifications,
  })
})

// --- Email verification ---------------------------------------------------
// Tokens are one-shot, expire after 24h. Hashed at rest so a DB leak doesn't
// hand attackers a free verification on every account. The actual link is
// surfaced via:
//   1. A persisted Notification (kind='security') so the user can copy it
//      from the bell menu in the UI even without SMTP wired up, and
//   2. Returned in the API response when NODE_ENV !== 'production' to make
//      local / staging testing trivial.
const verifyLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: AuthedRequest) => req.userId || req.ip || 'anon',
})

const VERIFY_TTL_MS = 24 * 60 * 60 * 1000

function clientOriginFromReq(req: { headers: Record<string, string | string[] | undefined> }): string {
  const fromHeader = req.headers['origin']
  if (typeof fromHeader === 'string' && fromHeader) return fromHeader.replace(/\/$/, '')
  return env.APP_BASE_URL?.replace(/\/$/, '') || ''
}

router.post('/send-verification', requireAuth, verifyLimiter, async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.userId! }, select: { id: true, email: true, emailVerified: true } })
  if (!user) { res.status(404).json({ error: 'User not found' }); return }
  if (user.emailVerified) { res.json({ alreadyVerified: true }); return }

  const raw = crypto.randomBytes(32).toString('hex')
  const tokenHash = crypto.createHash('sha256').update(raw).digest('hex')
  const expiresAt = new Date(Date.now() + VERIFY_TTL_MS)

  // Invalidate any prior outstanding tokens for this user so attackers can't
  // hoard intercepted links — only the most-recent send is valid.
  await prisma.emailVerification.updateMany({ where: { userId: user.id, used: false }, data: { used: true } })
  await prisma.emailVerification.create({ data: { userId: user.id, tokenHash, expiresAt } })

  const origin = clientOriginFromReq(req)
  const link = origin ? `${origin}/verify-email?token=${raw}` : `/verify-email?token=${raw}`

  await prisma.notification.create({
    data: {
      userId: user.id,
      kind: 'security',
      title: 'Verify your email',
      body: `Tap the link to confirm ${user.email}: ${link} (expires in 24h)`,
    },
  })

  const isDev = (env.NODE_ENV || 'development') !== 'production'
  res.json({ sent: true, expiresAt, ...(isDev ? { devLink: link } : {}) })
})

const verifyEmailSchema = z.object({ token: z.string().min(20).max(200) })

router.post('/verify-email', authLimiter, async (req, res) => {
  const parsed = verifyEmailSchema.safeParse(req.body)
  if (!parsed.success) { res.status(400).json({ error: 'Invalid token' }); return }
  const tokenHash = crypto.createHash('sha256').update(parsed.data.token).digest('hex')
  const record = await prisma.emailVerification.findUnique({ where: { tokenHash } })
  if (!record || record.used || record.expiresAt < new Date()) {
    res.status(400).json({ error: 'Invalid or expired verification link' })
    return
  }
  await prisma.$transaction([
    prisma.user.update({ where: { id: record.userId }, data: { emailVerified: true, emailVerifiedAt: new Date() } }),
    prisma.emailVerification.update({ where: { id: record.id }, data: { used: true } }),
  ])
  res.json({ verified: true })
})

export default router
